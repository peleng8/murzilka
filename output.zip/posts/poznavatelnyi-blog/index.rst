.. title: Познавательный блог
.. slug: poznavatelnyi-blog
.. date: 2021-03-15 06:48:01 UTC+03:00
.. tags: вело, фото
.. category: 
.. link: 
.. description: 
.. type: text

.. image:: /images/Улыбка.jpg

Страницы:

* `Писатетели родного края <http://map.lib48.ru/index.php/personalii/zhili-prebyvali-v-lipetskom-krae/59-gorky-a-m>`__
* `Фото <link://gallery/1>`__
* `Фото <link://gallery/2>`__


Писать `туда <https://vk.com/eleng81>`_
